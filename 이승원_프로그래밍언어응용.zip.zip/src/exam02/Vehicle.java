package exam02;

public interface Vehicle {
	
	public abstract void accelate();
	void stop();
	void setStart();

}
